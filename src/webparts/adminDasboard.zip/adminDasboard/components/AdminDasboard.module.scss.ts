/* tslint:disable */
require("./AdminDasboard.module.css");
const styles = {
  adminDasboard: 'adminDasboard_b224cde1',
  teams: 'teams_b224cde1',
  welcome: 'welcome_b224cde1',
  welcomeImage: 'welcomeImage_b224cde1',
  links: 'links_b224cde1'
};

export default styles;
/* tslint:enable */